package com.example.pato.model;


public class ImagesModel {
    public String imageUrl;
    public String imageUrlP;
    public String imageUrlr_P;
    public String imageUrlQ;
    public String imageUrlQQ;
    public String imageUrlr_Q;
    public String imageUrlW;
    public String imageUrlWW;
    public String imageUrlr_W;
    public String imageUrlE;
    public String imageUrlEE;
    public String imageUrlr_E;
    public String imageUrlR;
    public String imageUrlRR;
    public String imageUrlr_R;
    public String patchKey;

}
