package com.example.pato.model;

public class UserModel {
    public String email;
    public String nickname;
    public String uid;
    public String pushToken;
    public String password;
}
