package com.example.pato.model;


public class ContestModel {


    public static class RANKS{
        public String WIN;
        public String LOSE;
        public int RANK;
        public String REMARK;
        public String GAIN;
        public String logoImage;
    }

    public static class MVP_RANKS{
        public String id;
        public String team;
        public int point;
        public String position;
    }

    public static class scheDule{

        public String fgt;
        public String ft;
        public String ft2;

        public String sgt;
        public String st;
        public String st2;

        public String tgt;
        public String tt;
        public String tt2;

        public String relay;

    }
}
