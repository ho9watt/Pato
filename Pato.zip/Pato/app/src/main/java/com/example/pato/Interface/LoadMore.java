package com.example.pato.Interface;


public interface LoadMore {
    void onLoadMore();
}
