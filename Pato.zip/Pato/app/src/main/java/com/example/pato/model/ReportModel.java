package com.example.pato.model;


public class ReportModel {
    public String uid;
    public String bid;
    public String time;
    public String rs;
    public String repU;

}
